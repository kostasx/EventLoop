import React from "react";
import ReactDOM from "react-dom";
import "./styles.css";
import logo from "./JavaScript-logo.jpg";

let styles = {
  backgroundColor: "hotpink",
  border: "5px solid black"
};

function App() {
  return (
    <div className="App">
      <h1 style={styles}>Hello CodeSandbox</h1>
      <img src={logo} width="200" />
      <h2 style={{ borderBottom: "5px solid orange" }}>
        JavaScript and React.JS is Magic!
      </h2>
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
