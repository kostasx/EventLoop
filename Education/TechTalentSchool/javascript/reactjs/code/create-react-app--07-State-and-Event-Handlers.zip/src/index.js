import React from "react";
import ReactDOM from "react-dom";
import Counter from "./Counter";

class App extends React.Component {
  render() {
    return (
      <div>
        <h1>My App</h1>
        <Counter init={10} color="hotpink" />
        <Counter init={2} color="green" />
      </div>
    );
  }
}

ReactDOM.render(<App />, document.querySelector("#root"));
