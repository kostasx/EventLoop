import React from "react";
import ReactDOM from "react-dom";

let msg = <h1>Hello World</h1>;

ReactDOM.render(msg, document.getElementById("root"));
