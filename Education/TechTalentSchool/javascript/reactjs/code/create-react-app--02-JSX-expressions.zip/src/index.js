import React from "react";
import ReactDOM from "react-dom";

function upper(txt) {
  return txt.toUpperCase();
}
let name = "kostas";
let msg = <h1>{upper(name)}<br/>2+2={2+2}</h1>;

ReactDOM.render(msg, document.getElementById("root"));
