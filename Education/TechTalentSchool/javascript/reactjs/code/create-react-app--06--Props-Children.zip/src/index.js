import React from "react";
import ReactDOM from "react-dom";
import "./styles.css";
import MyButton from "./components/Button.jsx";

function App() {
  return (
    <div className="App">
      <MyButton color="red">Hurray!</MyButton>
      <h1>Main App</h1>
    </div>
  );
}

const rootElement = document.getElementById("root");

// ReactDOM.render( JSX expression, DOM element )
// 1st argument appended to 2nd argument
ReactDOM.render(<App />, rootElement);
